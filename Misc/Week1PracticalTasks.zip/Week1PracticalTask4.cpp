// Unit Conversion Challenge - Create a program that converts a length in inches to multiple units.

#include <iostream>

use namespace std;

int main()
{
	// Ask the user to input a length in inches.
	
	
	// Convert the length to feet using the formula: 1 foot = 12 inches.
	
	
	// Convert the length to meters using the formula: 1 inch = 0.0254 meters.
	
	
	// Convert the length to centimeters using the formula: 1 inch = 2.54 centimeters.
	
	
	// Print all the converted values.
}