// Calculate Average. Write a program to calculate the average of numbers entered by the user.

#include <iostream>

use namespace std;

int main()
{
	// Ask the user to input three numbers.
	int datum1;
	cout << "This simple program will give you the average of five numbers. Please enter the first whole number: ";
	cin >> datum1;
	
	int datum2;
	cout << "Please enter the second whole number: ";
	cin >> datum2;
	
	int datum3;
	cout << "Please enter the third whole number: ";
	cin >> datum3;
	
	int datum4;
	cout << "Please enter the fourth whole number: ";
	cin >> datum4;
	
	int datum5;
	cout << "Please enter the fifth whole number: ";
	cin >> datum5;
	
// Calculate the sum and divide by 5 to get the average.
	int sum = (datum1 + datum2 + datum3 + datum4 + datum5);
	int product = (datum1 * datum2 * datum3 * datum4 * datum5);
	float average = sum / 5;
	
// Print the result.
	cout << "The sum of the five numbers is: " << sum << endl;
	cout << "The product of the five numbers is: " << product << endl;                                                                                                                                                                                                                                                                                                            of the five numbers is: " << average << endl;
	cout << "The average of the five numbers is: " << average << endl;

// Bonus - Modify the program to accept five numbers. Also calculate and display the sum and product of the numbers entered.
}